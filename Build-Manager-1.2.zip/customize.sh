#!/system/bin/sh

  ui_print "************************"
  ui_print " Enabling Build Manager "
  ui_print "************************"