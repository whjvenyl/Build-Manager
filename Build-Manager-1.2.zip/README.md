## Build Manager
* This module activates the options and optimizes others `build.prop`.

## Liste devices
* Redmi Note 7 Pro

## What does this module change?
* Optimization RAM
* Dalvik Virtual Machine
* Stream Videos Faster
* Better Internet Speed
* Better Scrolling
* Better RAM management
* Modify Logcat

## Changelog
* 06-04-2020 (v1.1): Support Magisk v19x 
* 05-04-2020 (v1.0): Initial commit.
